--Dummy Data for Book Store Management System
Use BOOK_STORE

-- Insert data into Author Table
INSERT INTO Author (AuthorID, Name, Biography, Nationality)
VALUES
(1, 'John Doe', 'Author of many books', 'American'),
(2, 'Jane Smith', 'Famous novelist', 'British');

-- Insert data into Publisher Table
INSERT INTO Publisher (PublisherID, Name, Address, ContactInfo)
VALUES
(1, 'ABC Publications', '123 Main Street', '555-1234'),
(2, 'XYZ Books', '456 Oak Avenue', '555-5678');

-- Insert data into Customer Table
INSERT INTO Customer (CustomerID, Name, ContactDetails, Address)
VALUES
(1, 'Alice Johnson', '555-9876', '789 Elm Street'),
(2, 'Bob Williams', '555-5432', '101 Pine Avenue');

-- Insert data into Book Table
INSERT INTO Book (ISBN, Title, AuthorID, PublicationDate, PublisherID, Price, QuantityInStock)
VALUES
('1234567890', 'The Great Book', 1, '2022-01-01', 1, 19.99, 100),
('0987654321', 'Fantastic Novel', 2, '2022-02-01', 2, 24.99, 75);

-- Insert data into Orders Table
INSERT INTO Orders (OrderID, OrderDate, CustomerID, TotalCost, Status)
VALUES
(1, '2022-03-01', 1, 39.98, 'Shipped'),
(2, '2022-03-02', 2, 74.98, 'Pending');

-- Insert data into B_Transaction Table
INSERT INTO B_Transaction (TransactionID, TransactionDate, OrderID, PaymentMethod, TotalAmount)
VALUES
(1, '2022-03-01', 1, 'Credit Card', 39.98),
(2, '2022-03-02', 2, 'PayPal', 74.98);

-- Insert data into Employee Table
INSERT INTO Employee (EmployeeID, Name, Position, ContactDetails)
VALUES
(1, 'Mary Johnson', 'Manager', '555-1111'),
(2, 'Sam Brown', 'Sales Representative', '555-2222');

-- Insert data into OrderItem Table
INSERT INTO OrderItem (OrderItemID, OrderID, ISBN, Quantity, PricePerUnit)
VALUES
(1, 1, '1234567890', 2, 19.99),
(2, 1, '0987654321', 1, 24.99),
(3, 2, '0987654321', 3, 24.99);

-- Insert data into Genre Table
INSERT INTO Genre (GenreID, Name)
VALUES
(1, 'Fiction'),
(2, 'Mystery');

-- Insert data into BookGenre Table
INSERT INTO BookGenre (BookGenreID, ISBN, GenreID)
VALUES
(1, '1234567890', 1),
(2, '0987654321', 2),
(3, '0987654321', 1);

-- Insert data into AuthorBook Table
INSERT INTO AuthorBook (AuthorBookID, AuthorID, ISBN)
VALUES
(1, 1, '1234567890'),
(2, 2, '0987654321');

-- Insert data into EmployeeOrder Table
INSERT INTO EmployeeOrder (EmployeeOrderID, EmployeeID, OrderID)
VALUES
(1, 1, 1),
(2, 2, 2);
