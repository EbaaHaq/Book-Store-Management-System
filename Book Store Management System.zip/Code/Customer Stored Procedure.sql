
--Stored Procedure foR geting Customer Information using CustomerID
CREATE PROCEDURE GetCustomerInformation
    @CustomerID INT
AS
BEGIN
    SELECT *
    FROM Customer
    WHERE CustomerID = @CustomerID;
END;