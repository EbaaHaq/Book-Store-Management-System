﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store_Management_System
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string currentTable = "";
            currentTable = "Author";
            try
            {
                SqlCommand command = new SqlCommand();
                //SqlConnection connection = new SqlConnection(@"Data Source = (local)\SQLEXPRESS; Initial Catalog = BOOK_STORE; Integrated Security = True");
                var datasource = @"DESKTOP-VIU51SB\SQLEXPRESS";
                var database = "BOOK_STORE";
                var thisUsername = Form3.username;
                var thisPassword = Form3.password;
                string connString = @"Data Source=" + datasource + ";Initial Catalog=" + database + ";Persist Security Info=True;User ID=" + thisUsername + ";Password=" + thisPassword;
                SqlConnection conn = new SqlConnection(connString); conn.Open();
                dataGridView1.Text = "Retrieving Records...";
                command.Connection = conn;
                command.CommandText = "select * from " + currentTable;
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;
                dataGridView1.Text = "Retrieval Successful!";
                conn.Close();
            }
            catch (Exception ex)
            {
                dataGridView1.Text = "Error, " + ex;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Check if any TextBox is empty
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text) || string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Please fill in all the fields.");
                return;
            }

            try
            {
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-VIU51SB\SQLEXPRESS;Initial Catalog=BOOK_STORE;Integrated Security=True");
                connection.Open();

                command.Connection = connection;
                // Assuming OrderItemID is an identity column and does not need to be provided explicitly
                command.CommandText = "INSERT INTO  Author(AuthorID, Name, Biography, Nationality) VALUES('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')";
                command.ExecuteNonQuery();
                connection.Close();

                MessageBox.Show("Successfully Added.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Assuming you have a unique identifier for the record, let's use AuthorID as an example
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Please enter Author ID to delete.");
                return;
            }

            try
            {
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-VIU51SB\SQLEXPRESS;Initial Catalog=BOOK_STORE;Integrated Security=True");
                connection.Open();

                command.Connection = connection;
                // Assuming AuthorID is an integer, adjust the type accordingly if it's different
                command.CommandText = "DELETE FROM Author WHERE AuthorID = " + textBox1.Text;
                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Record deleted successfully.");
                }
                else
                {
                    MessageBox.Show("No matching record found for the given Author ID.");
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Assuming you want to search based on AuthorID
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Please enter Author ID to search.");
                return;
            }

            try
            {
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-VIU51SB\SQLEXPRESS;Initial Catalog=BOOK_STORE;Integrated Security=True");
                connection.Open();

                command.Connection = connection;
                // Assuming AuthorID is an integer, adjust the type accordingly if it's different
                command.CommandText = "SELECT * FROM Author WHERE AuthorID = " + textBox1.Text;

                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dataGridView1.DataSource = dt;
                    MessageBox.Show("Record found successfully.");
                }
                else
                {
                    dataGridView1.DataSource = null; // Clear previous search results
                    MessageBox.Show("No matching record found for the given Author ID.");
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Check if any TextBox is empty
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text) || string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Please fill in all the fields.");
                return;
            }

            try
            {
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-VIU51SB\SQLEXPRESS;Initial Catalog=BOOK_STORE;Integrated Security=True");
                connection.Open();

                command.Connection = connection;

                // Assuming AuthorID is an integer, adjust the type accordingly if it's different
                int authorId;
                if (int.TryParse(textBox1.Text, out authorId))
                {
                    // Assuming AuthorID is an identity column and does not need to be provided explicitly
                    command.CommandText = "UPDATE Author SET Name = '" + textBox2.Text + "', Biography = '" + textBox3.Text + "', Nationality = '" + textBox4.Text + "' WHERE AuthorID = " + authorId;
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Record updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("No matching record found for the given Author ID.");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Author ID. Please enter a valid integer.");
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

    }
}
