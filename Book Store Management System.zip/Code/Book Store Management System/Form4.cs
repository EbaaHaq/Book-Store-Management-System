﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store_Management_System
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        string currentTable = "";
        private void button2_Click(object sender, EventArgs e)
        {
            
            if (Form3.username == "User_Sales")
            {
                // Allow access to Orders and Customers table
                if (radioButton5.Checked)
                {
                    currentTable = "Customer";
                }
                else if (radioButton6.Checked)
                {
                    currentTable = "Orders";
                }
                else if (radioButton8.Checked)
                {
                    currentTable = "B_Transaction";
                }
                else if (radioButton7.Checked)
                {
                    currentTable = "OrderItem";
                }
                else if (radioButton9.Checked)
                {
                    currentTable = "EmployeeOrder";
                }
                else
                {
                    dataGridView1.DataSource = null;
                    MessageBox.Show("You do not have access to this table.");
                }
            }
            else if (Form3.username == "User_HR")
            {
                if (radioButton2.Checked)
                {
                    currentTable = "Book";
                }
                else if (radioButton3.Checked)
                {
                    currentTable = "Author";
                }
                else if (radioButton4.Checked)
                {
                    currentTable = "Publisher";
                }
                else if (radioButton10.Checked)
                {
                    currentTable = "Genre";
                }
                else if (radioButton11.Checked)
                {
                    currentTable = "BookGenre";
                }
                else if (radioButton12.Checked)
                {
                    currentTable = "AuthorBook";
                }
                else
                {
                    dataGridView1.DataSource = null;
                    MessageBox.Show("You do not have access to this table.");
                }
            }
            else if (Form3.username == "User_CEO")
            {
                if (radioButton1.Checked)
                {
                    currentTable = "Employee";
                }
                else if (radioButton2.Checked)
                {
                    currentTable = "Book";
                }
                else if (radioButton3.Checked)
                {
                    currentTable = "Author";
                }
                else if (radioButton4.Checked)
                {
                    currentTable = "Publisher";
                }
                else if (radioButton5.Checked)
                {
                    currentTable = "Customer";
                }
                else if (radioButton6.Checked)
                {
                    currentTable = "Orders";
                }
                else if (radioButton7.Checked)
                {
                    currentTable = "OrderItem";
                }
                else if (radioButton8.Checked)
                {
                    currentTable = "B_Transaction";
                }
                else if (radioButton9.Checked)
                {
                    currentTable = "EmployeeOrder";
                }
                else if (radioButton10.Checked)
                {
                    currentTable = "Genre";
                }
                else if (radioButton11.Checked)
                {
                    currentTable = "BookGenre";
                }
                else if (radioButton12.Checked)
                {
                    currentTable = "AuthorBook";
                }
                else
                {
                    dataGridView1.DataSource = null;
                    MessageBox.Show("You do not have access to this table.");
                }
            }

            try
            {
                SqlCommand command = new SqlCommand();
                //SqlConnection connection = new SqlConnection(@"Data Source = (local)\SQLEXPRESS; Initial Catalog = BOOK_STORE; Integrated Security = True");
                var datasource = @"DESKTOP-VIU51SB\SQLEXPRESS";
                var database = "BOOK_STORE";
                var thisUsername = Form3.username;
                var thisPassword = Form3.password;
                string connString = @"Data Source=" + datasource + ";Initial Catalog=" + database + ";Persist Security Info=True;User ID=" + thisUsername + ";Password=" + thisPassword;
                SqlConnection conn = new SqlConnection(connString); conn.Open();
                dataGridView1.Text = "Retrieving Records..."; command.Connection = conn;
                command.CommandText = "select * from " + currentTable;
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable(); da.Fill(dt);

                dataGridView1.DataSource = dt;
                dataGridView1.Text = "Retrieval Successful!"; conn.Close();
            }
            catch (Exception ex)
            {
                dataGridView1.Text = "Error, " + ex;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            try
            {
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-VIU51SB\SQLEXPRESS;Initial Catalog=BOOK_STORE;Integrated Security=True");
                connection.Open();
                textBox1.Text = "Counting Records...";

                // Use parameterized query to avoid SQL injection
                command.Connection = connection;
                command.CommandText = "SELECT COUNT(*) FROM " + "[" + currentTable + "]";
                int count = (int)command.ExecuteScalar();
                textBox1.Text = "Number of records: " + count;

                connection.Close();
            }
            catch (Exception ex)
            {
                textBox1.Text = "Error: " + ex.Message;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Succesfully Log Out.");
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (Form3.username == "User_Sales")
            {
                // Allow access to Orders and Customers table
                if (radioButton5.Checked)
                {
                    Form12 ManageCustomer = new Form12();
                    ManageCustomer.ShowDialog();
                }
                else if (radioButton6.Checked)
                {
                    Form13 ManageOrders = new Form13();
                    ManageOrders.ShowDialog();
                }
                else if (radioButton8.Checked)
                {
                    Form19 ManageB_Transaction = new Form19();
                    ManageB_Transaction.ShowDialog();
                }
                else if (radioButton7.Checked)
                {
                    Form18 ManageOrderItemID = new Form18();
                    ManageOrderItemID.ShowDialog();
                }
                else if (radioButton9.Checked)
                {
                    Form9 EmployeeOrder = new Form9();  
                    EmployeeOrder.ShowDialog();
                }
                else
                {
                    dataGridView1.DataSource = null;
                    MessageBox.Show("You do not have access to this table.");
                }
            }
            else if (Form3.username == "User_HR")
            {
                if (radioButton2.Checked)
                {
                    Form14 ManageBook = new Form14();
                    ManageBook.ShowDialog();
                }
                else if (radioButton3.Checked)
                {
                    Form10 Author = new Form10();   
                    Author.ShowDialog();    
                }
                else if (radioButton4.Checked)
                {
                    Form15 ManagePublisher = new Form15();
                    ManagePublisher.ShowDialog();
                }
                else if (radioButton10.Checked)
                {
                    Form16 ManageGenre = new Form16();
                    ManageGenre.ShowDialog();
                }
                else if (radioButton11.Checked)
                {
                    Form17 ManageBookGenre = new Form17();  
                    ManageBookGenre.ShowDialog();
                }
                else if (radioButton12.Checked)
                {
                    Form11 AuthorBook = new Form11();
                    AuthorBook.ShowDialog();
                }
                else
                {
                    dataGridView1.DataSource = null;
                    MessageBox.Show("You do not have access to this table.");
                }
            }
            else if (Form3.username == "User_CEO")
            {
                if (radioButton1.Checked)
                {
                    Form8 ManageEmployee = new Form8();   
                    ManageEmployee.ShowDialog();
                }
                else if (radioButton2.Checked)
                {
                    Form14 ManageBook = new Form14();       
                    ManageBook.ShowDialog();    
                }
                else if (radioButton3.Checked)
                {
                    Form10 Author = new Form10();
                    Author.ShowDialog();
                }
                else if (radioButton4.Checked)
                {
                    Form15 ManagePublisher = new Form15();
                    ManagePublisher.ShowDialog();
                }
                else if (radioButton5.Checked)
                {
                    Form12 ManageCustomer = new Form12();   
                    ManageCustomer.ShowDialog();
                }
                else if (radioButton6.Checked)
                {
                    Form13 ManageOrders = new Form13(); 
                    ManageOrders.ShowDialog();  
                }
                else if (radioButton7.Checked)
                {
                    Form18 ManageOrderItemID = new Form18();
                    ManageOrderItemID.ShowDialog();
                }
                else if (radioButton8.Checked)
                {
                    Form19 ManageB_Transaction = new Form19();  
                    ManageB_Transaction.ShowDialog();
                }
                else if (radioButton9.Checked)
                {
                    Form9 EmployeeOrder = new Form9();
                    EmployeeOrder.ShowDialog();
                }
                else if (radioButton10.Checked)
                {
                    Form16 ManageGenre = new Form16();  
                    ManageGenre.ShowDialog();
                }
                else if (radioButton11.Checked)
                {
                    Form17 ManageBookGenre = new Form17();
                    ManageBookGenre.ShowDialog();
                }
                else if (radioButton12.Checked)
                {
                    Form11 AuthorBook = new Form11();   
                    AuthorBook.ShowDialog();    
                }
                else
                {
                    dataGridView1.DataSource = null;
                    MessageBox.Show("You do not have access to this table.");
                }
            }
        }
    }
}
