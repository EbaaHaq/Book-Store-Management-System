﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store_Management_System
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 customer_details = new Form6();
            customer_details.ShowDialog();  

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form7 order = new Form7();  
            order.ShowDialog();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                var datasource = @"DESKTOP-VIU51SB\SQLEXPRESS";
                var database = "BOOK_STORE";
                string currentTable = "Book";
                string connString = @"Data Source=" + datasource + ";Initial Catalog=" + database + ";Integrated Security=True";
                SqlConnection conn = new SqlConnection(connString);
                conn.Open();

                SqlCommand command = new SqlCommand("SELECT * FROM " + currentTable, conn);
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.Invoke(new Action(() =>
                {
                    dataGridView1.DataSource = dt;
                    dataGridView1.Text = "Retrieval Successful!";
                }));

                conn.Close();
            }
            catch (Exception ex)
            {
                dataGridView1.Invoke(new Action(() => dataGridView1.Text = "Error: " + ex.ToString()));
            }
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
