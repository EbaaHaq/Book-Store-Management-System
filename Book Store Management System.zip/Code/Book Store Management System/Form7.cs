﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store_Management_System
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Check if any TextBox is empty
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text) ||
                string.IsNullOrWhiteSpace(textBox4.Text) ||
                string.IsNullOrWhiteSpace(textBox5.Text))
            {
                MessageBox.Show("Please fill in all the fields.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-VIU51SB\SQLEXPRESS;Initial Catalog=BOOK_STORE;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandText = "INSERT INTO OrderItem (OrderItemID, OrderID, ISBN, Quantity, PricePerUnit) VALUES(@OrderItemID, @OrderID, @ISBN, @Quantity, @PricePerUnit)";
                        command.Parameters.AddWithValue("@OrderItemID", textBox1.Text);
                        command.Parameters.AddWithValue("@OrderID", textBox2.Text);
                        command.Parameters.AddWithValue("@ISBN", textBox3.Text);
                        command.Parameters.AddWithValue("@Quantity", textBox4.Text);
                        command.Parameters.AddWithValue("@PricePerUnit", textBox5.Text);

                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Successfully Added.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

    

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
