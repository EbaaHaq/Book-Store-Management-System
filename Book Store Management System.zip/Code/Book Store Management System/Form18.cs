﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store_Management_System
{
    public partial class Form18 : Form
    {
        public Form18()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            string currentTable = "";
            currentTable = "OrderItem";
            try
            {
                SqlCommand command = new SqlCommand();
                //SqlConnection connection = new SqlConnection(@"Data Source = (local)\SQLEXPRESS; Initial Catalog = BOOK_STORE; Integrated Security = True");
                var datasource = @"DESKTOP-VIU51SB\SQLEXPRESS";
                var database = "BOOK_STORE";
                var thisUsername = Form3.username;
                var thisPassword = Form3.password;
                string connString = @"Data Source=" + datasource + ";Initial Catalog=" + database + ";Persist Security Info=True;User ID=" + thisUsername + ";Password=" + thisPassword;
                SqlConnection conn = new SqlConnection(connString); conn.Open();
                dataGridView1.Text = "Retrieving Records...";
                command.Connection = conn;
                command.CommandText = "select * from " + currentTable;
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;
                dataGridView1.Text = "Retrieval Successful!";
                conn.Close();
            }
            catch (Exception ex)
            {
                dataGridView1.Text = "Error, " + ex;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Check if any TextBox is empty
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text) || string.IsNullOrWhiteSpace(textBox4.Text) || 
                string.IsNullOrWhiteSpace(textBox5.Text)
                )
            {
                MessageBox.Show("Please fill in all the fields.");
                return;
            }

            try
            {
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-VIU51SB\SQLEXPRESS;Initial Catalog=BOOK_STORE;Integrated Security=True");
                connection.Open();

                command.Connection = connection;
                // Assuming OrderItemID is an identity column and does not need to be provided explicitly
                command.CommandText = "INSERT INTO OrderItem (OrderItemID, OrderID, ISBN, Quantity, PricePerUnit) VALUES('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "')";
                command.ExecuteNonQuery();
                connection.Close();

                MessageBox.Show("Successfully Added.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Assuming you have a unique identifier for the record, let's use OrderItemID as an example
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Please enter OrderItemID to delete.");
                return;
            }

            try
            {
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-VIU51SB\SQLEXPRESS;Initial Catalog=BOOK_STORE;Integrated Security=True");
                connection.Open();

                command.Connection = connection;
                // Assuming OrderItemID is an integer, adjust the type accordingly if it's different
                command.CommandText = "DELETE FROM OrderItem WHERE OrderItemID = " + textBox1.Text;
                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Record deleted successfully.");
                }
                else
                {
                    MessageBox.Show("No matching record found for the given OrderItemID.");
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Assuming you want to search based on OrderItemID
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Please enter OrderItemID to search.");
                return;
            }

            try
            {
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-VIU51SB\SQLEXPRESS;Initial Catalog=BOOK_STORE;Integrated Security=True");
                connection.Open();

                command.Connection = connection;
                // Assuming OrderItemID is an integer, adjust the type accordingly if it's different
                command.CommandText = "SELECT * FROM OrderItem WHERE OrderItemID = " + textBox1.Text;

                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dataGridView1.DataSource = dt;
                    MessageBox.Show("Record found successfully.");
                }
                else
                {
                    dataGridView1.DataSource = null; // Clear previous search results
                    MessageBox.Show("No matching record found for the given OrderItemID.");
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Check if any TextBox is empty
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text) || string.IsNullOrWhiteSpace(textBox4.Text) ||
                string.IsNullOrWhiteSpace(textBox5.Text))
            {
                MessageBox.Show("Please fill in all the fields.");
                return;
            }

            try
            {
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-VIU51SB\SQLEXPRESS;Initial Catalog=BOOK_STORE;Integrated Security=True");
                connection.Open();

                command.Connection = connection;

                // Assuming OrderItemID is an integer, adjust the type accordingly if it's different
                int orderItemId;
                if (int.TryParse(textBox1.Text, out orderItemId))
                {
                    // Assuming OrderItemID is an identity column and does not need to be provided explicitly
                    command.CommandText = "UPDATE OrderItem SET OrderID = '" + textBox2.Text + "', ISBN = '" + textBox3.Text + "', Quantity = '" + textBox4.Text + "', PricePerUnit = '" + textBox5.Text + "' WHERE OrderItemID = " + orderItemId;
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Record updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("No matching record found for the given OrderItemID.");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid OrderItemID. Please enter a valid integer.");
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

    }
}
