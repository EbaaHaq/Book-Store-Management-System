--Schema of Book Store Management System

USE BOOK_STORE;
-- Author Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Author')
BEGIN
    CREATE TABLE Author (
        AuthorID INT PRIMARY KEY,
        Name VARCHAR(255),
        Biography TEXT,
        Nationality VARCHAR(50)
    );
END;

-- Publisher Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Publisher')
BEGIN
    CREATE TABLE Publisher (
        PublisherID INT PRIMARY KEY,
        Name VARCHAR(255),
        Address VARCHAR(255),
        ContactInfo VARCHAR(50)
    );
END;

-- Customer Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Customer')
BEGIN
    CREATE TABLE Customer (
        CustomerID INT PRIMARY KEY,
        Name VARCHAR(255),
        ContactDetails VARCHAR(50),
        Address VARCHAR(255)
    );
END;

-- Book Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Book')
BEGIN
    CREATE TABLE Book (
        ISBN VARCHAR(20) PRIMARY KEY,
        Title VARCHAR(255),
        AuthorID INT,
        PublicationDate DATE,
        PublisherID INT,
        Price DECIMAL(10, 2),
        QuantityInStock INT,
        FOREIGN KEY (AuthorID) REFERENCES Author(AuthorID),
        FOREIGN KEY (PublisherID) REFERENCES Publisher(PublisherID)
    );
END;

-- Order Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Orders')
BEGIN
    CREATE TABLE Orders (
        OrderID INT PRIMARY KEY,
        OrderDate DATE,
        CustomerID INT,
        TotalCost DECIMAL(10, 2),
        Status VARCHAR(20),
        FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
    );
END;

-- Transaction Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'B_Transaction')
BEGIN
    CREATE TABLE B_Transaction (
        TransactionID INT PRIMARY KEY,
        TransactionDate DATE,
        OrderID INT,
        PaymentMethod VARCHAR(50),
        TotalAmount DECIMAL(10, 2),
        FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
    );
END;

-- OrderItem Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'OrderItem')
BEGIN
    CREATE TABLE OrderItem (
        OrderItemID INT PRIMARY KEY,
        OrderID INT,
        ISBN VARCHAR(20),
        Quantity INT,
        PricePerUnit DECIMAL(10, 2),
        FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
        FOREIGN KEY (ISBN) REFERENCES Book(ISBN)
    );
END;

-- Employee Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Employee')
BEGIN
    CREATE TABLE Employee (
        EmployeeID INT PRIMARY KEY,
        Name VARCHAR(255),
        Position VARCHAR(50),
        ContactDetails VARCHAR(50)
    );
END;

-- Genre Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Genre')
BEGIN
    CREATE TABLE Genre (
        GenreID INT PRIMARY KEY,
        Name VARCHAR(50)
    );
END;

-- BookGenre Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'BookGenre')
BEGIN
    CREATE TABLE BookGenre (
        BookGenreID INT PRIMARY KEY,
        ISBN VARCHAR(20),
        GenreID INT,
        FOREIGN KEY (ISBN) REFERENCES Book(ISBN),
        FOREIGN KEY (GenreID) REFERENCES Genre(GenreID)
    );
END;

-- AuthorBook Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'AuthorBook')
BEGIN
    CREATE TABLE AuthorBook (
        AuthorBookID INT PRIMARY KEY,
        AuthorID INT,
        ISBN VARCHAR(20),
        FOREIGN KEY (AuthorID) REFERENCES Author(AuthorID),
        FOREIGN KEY (ISBN) REFERENCES Book(ISBN)
    );
END;

-- EmployeeOrder Table
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'EmployeeOrder')
BEGIN
    CREATE TABLE EmployeeOrder (
        EmployeeOrderID INT PRIMARY KEY,
        EmployeeID INT,
        OrderID INT,
        FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID),
        FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
    );
END;
